# ניהול פיננסי - הפרח בגני: העלאה ל-GitHub עם התחברות בטלפון

בלי ההגדרות האלה האתר עובד, אבל הנתונים נשמרים רק במכשיר שבו עובדים.
עם ההגדרות: כל מספר מורשה נכנס עם טלפון וסיסמה, ורואה את אותם נתונים בזמן אמת מכל מכשיר. מספר שלא אושר נחסם.

## 1. יצירת פרויקט Firebase (חינם, בלי כרטיס אשראי)
1. נכנסים ל-https://console.firebase.google.com ולוחצים **Add project**. שם לדוגמה: `haperach-shop`.
2. **Build → Authentication → Get started → Sign-in method** ומפעילים **Email/Password**.
   (האתר הופך מספר טלפון לשם משתמש. אין שליחת SMS, ולכן אין עלות.)
3. **Authentication → Settings → Authorized domains → Add domain** ומוסיפים `haperach-begani.github.io` (או הכתובת שלך ב-GitHub).
4. **Build → Firestore Database → Create database**. בוחרים מיקום `eur3` ו-Production mode.
5. **Firestore → Rules**: מדביקים את כל התוכן של `firestore.rules`. בשורה `ownerPhone` מחליפים את `972XXXXXXXXX` במספר של רון (בלי האפס, עם 972 בהתחלה) ולוחצים **Publish**.
6. **Project settings (גלגל שיניים) → Your apps → Web (`</>`)**: רושמים אפליקציה ומעתיקים את אובייקט `firebaseConfig`.

## 2. עדכון הקובץ index.html
מחפשים בקובץ את השורות האלה וממלאים:
```js
const FIREBASE_CONFIG={apiKey:"...",authDomain:"...",projectId:"...",storageBucket:"...",messagingSenderId:"...",appId:"..."};
const OWNER_PHONE="0541234567"; // המספר של רון
```

## 3. העלאה ל-GitHub Pages
מעלים את `index.html` לריפו, למשל לתיקייה `finance/`, ונכנסים ל-`https://haperach-begani.github.io/finance/`.

## 4. כניסה ראשונה
1. רון נכנס עם המספר שלו ולוחץ **"פעם ראשונה? יצירת סיסמה למספר שלי"**.
2. ב**קבועות → משתמשים מורשים** הוא מוסיף מספרים נוספים (למשל שלך).
3. כל מספר שנוסף נכנס פעם ראשונה עם "יצירת סיסמה", ומאז עם "כניסה".

## חשוב לדעת
- **שכחו סיסמה:** ב-Firebase → Authentication → Users מוחקים את המשתמש, והוא יוצר סיסמה מחדש.
- **שני אנשים עורכים בדיוק באותו רגע:** השמירה האחרונה גוברת. בחנות עם 1–3 משתמשים זה כמעט לא קורה, אבל כדאי להוריד גיבוי מדי פעם.
- **רוצים קוד ב-SMS במקום סיסמה?** אפשר, אבל Firebase דורש בשביל זה תוכנית Blaze עם כרטיס אשראי ותשלום לכל SMS.
